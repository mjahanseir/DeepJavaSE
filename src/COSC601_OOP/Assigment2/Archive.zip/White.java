package Assigment2;

public class White extends Dragon{
    /////////////////////     Attributes    /////////////////////
    public String sName;

    /////////////////////     Methods    /////////////////////
    public White(DragonSize nSize, String sName) {
        super(nSize);
        this.sName = sName;
    }

    @Override
    public void defendAttack(Dragon obOther) {
        if (obOther.equals("Red")) {
            resurrect( 80 - getDefense() );
        }else if (obOther.equals("Green")){
            resurrect( 110 - getDefense() );
        }else if (obOther.equals("White")){
            resurrect( 100 - getDefense() );
        }else if (obOther.equals("Black")) {
            resurrect(100 - getDefense());
        }
    }

    @Override
    public String toString() {
        return "White[ sName='" + sName + "']";
    }
}
