package Assigment2;

public interface DragonAttacker {
     void defendAttack(Dragon obOther);

}
