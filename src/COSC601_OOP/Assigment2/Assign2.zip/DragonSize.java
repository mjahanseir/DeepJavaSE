package Assigment2;

public enum DragonSize {
    Large, Medium, Small;
}
