package AssignmentUML.AssignmentUML5.busDepotApp;

public enum FeatureType {
     Movies, Gaming, Music;
}
